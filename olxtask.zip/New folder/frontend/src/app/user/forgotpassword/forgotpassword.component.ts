import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { UserService } from 'src/app/shared/user.service';

@Component({
  selector: 'app-forgotpassword',
  templateUrl: './forgotpassword.component.html',
  styleUrls: ['./forgotpassword.component.css']
})
export class ForgotpasswordComponent implements OnInit {

  constructor(private userService: UserService) { }
  model ={
   
    email :''
   
  };
  ngOnInit(): void {
  }
  onSubmit(form:NgForm):void{
    console.log(form.value);
    this.userService.forgotpassword(form.value).subscribe(res=>{
      console.log(res);
    })
  }

}
