import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import { UserService } from '../shared/user.service';

@Component({
  selector: 'app-viewitems',
  templateUrl: './viewitems.component.html',
  styleUrls: ['./viewitems.component.css']
})
export class ViewitemsComponent implements OnInit {
  listofitems:any='';
  userDetails: any;
  useremail: any;

  constructor(private router:Router,private userService: UserService, private http:HttpClient,private activatedRoute: ActivatedRoute) { }

  ngOnInit(): void {
    this.userService.getUserProfile().subscribe(
      (res:any) => {
        this.userDetails = res['user'];
      //  console.log(res["user"]["email"]);
        this.useremail=res['user']['email'];
      },
      err => { 
        console.log(err);
        
      }
    );
    //console.log(this.activatedRoute.snapshot.params.id);
    this.http.get('http://localhost:3000/api/viewitems/'+this.activatedRoute.snapshot.params.id).subscribe(res=>{
      console.log(res);
      this.listofitems=res;
    });

  }
    
  onClickSubmit(data:any){
   

    this.http.post('http://localhost:3000/api/additem',data).subscribe(res=>{
      console.log('from additem');
       console.log(res);
       this.router.navigateByUrl('/userpurchaseditems');
       
    });
//console.log(data);

  }
}
