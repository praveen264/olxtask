import { Routes } from '@angular/router';
import { UserComponent } from './user/user.component';
import { SignUpComponent } from './user/sign-up/sign-up.component';
import { SignInComponent } from './user/sign-in/sign-in.component';
import { UserProfileComponent } from './user-profile/user-profile.component';
import { AuthGuard } from './auth/auth.guard';
import { ForgotpasswordComponent } from './user/forgotpassword/forgotpassword.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { ViewitemsComponent } from './viewitems/viewitems.component';
import { UserpurchaseditemsComponent } from './userpurchaseditems/userpurchaseditems.component';


export const appRoutes: Routes = [
    {
        path: 'signup', component: UserComponent,
        children: [{ path: '', component: SignUpComponent }]
    },
    {
        path: 'login', component: UserComponent,
        children: [{ path: '', component: SignInComponent }]
    },
    {
        path: 'forgotpassword', component: UserComponent,
        children: [{ path: '', component: ForgotpasswordComponent }]
    },
    {
        path: 'userprofile', component: UserProfileComponent,canActivate:[AuthGuard]
    },
    {
        path: 'dashboard', component: DashboardComponent,canActivate:[AuthGuard]
    },
    {
        path: 'viewitems/:id', component: ViewitemsComponent,canActivate:[AuthGuard]
    },
    {
        path: 'userpurchaseditems', component: UserpurchaseditemsComponent,canActivate:[AuthGuard]
    },
    {
        path: '', redirectTo: '/login', pathMatch: 'full'
    }
];