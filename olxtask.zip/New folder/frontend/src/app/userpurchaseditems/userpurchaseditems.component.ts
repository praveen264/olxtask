import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { UserService } from '../shared/user.service';

@Component({
  selector: 'app-userpurchaseditems',
  templateUrl: './userpurchaseditems.component.html',
  styleUrls: ['./userpurchaseditems.component.css']
})
export class UserpurchaseditemsComponent implements OnInit {
  userDetails: any;
  useremail: any;
  listofitems: any;

  constructor(private http:HttpClient,private userService:UserService) { }

  ngOnInit(): void {
    this.userService.getUserProfile().subscribe(
      (res:any) => {
        this.userDetails = res['user'];
      //  console.log(res["user"]["email"]);
        this.useremail=res['user']['email'];
        this.http.post('http://localhost:3000/api/viewpurchaseditems/',{email:this.useremail}).subscribe(res=>{
          console.log(res);
          this.listofitems=res;
        });
      },
      err => { 
        console.log(err);
        
      }
    );
   
  }

}
