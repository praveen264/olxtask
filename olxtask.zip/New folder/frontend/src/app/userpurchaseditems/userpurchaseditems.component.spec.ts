import { ComponentFixture, TestBed } from '@angular/core/testing';

import { UserpurchaseditemsComponent } from './userpurchaseditems.component';

describe('UserpurchaseditemsComponent', () => {
  let component: UserpurchaseditemsComponent;
  let fixture: ComponentFixture<UserpurchaseditemsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ UserpurchaseditemsComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(UserpurchaseditemsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
