const express = require('express');
const router = express.Router();

const ctrlUser = require('../controllers/user.controller');
const ctrlUserPurchased = require('../controllers/userpurchased.controller');

const jwtHelper = require('../config/jwtHelper');

router.post('/register', ctrlUser.register);
router.post('/authenticate', ctrlUser.authenticate);
router.post('/forgotpassword',ctrlUser.forgotpassword);
router.post('/resetpassword',ctrlUser.resetpassword);

router.get('/userProfile',jwtHelper.verifyJwtToken, ctrlUser.userProfile);
router.get('/verification/:email/:id', ctrlUser.verification);
router.get('/items',ctrlUser.items);
router.get('/viewitems/:id',ctrlUser.viewitem);
router.post('/items',ctrlUser.additems);
router.post('/additem',ctrlUserPurchased.additem);
router.post('/viewpurchaseditems',ctrlUserPurchased.viewpurchaseditems);


module.exports = router;



