const mongoose = require('mongoose');
const passport = require('passport');
const _ = require('lodash');

const User = mongoose.model('User');
const Userpurchased = mongoose.model('Userpurchased');
const Items = mongoose.model('Items');
const bcrypt = require('bcryptjs');
const nodemailer = require('nodemailer');
const v4 = require('uuid');
const uuidV4 = v4.v4()
require('dotenv').config();


module.exports.additem = async(req, res, next) => {
    const userpurchased=new Userpurchased({
        itemname: req.body.itemname,
        category: req.body.category,
        price: req.body.price,
        email:req.body.useremail
       
    })
    try{
        const a1=await userpurchased.save();
        if(a1)
        {
            const removeitems=await Items.findById(req.body.itemid); 
            const a1 = await removeitems.remove();
            
        }  
        res.json(a1);
      }
      catch(err)
      {
          res.send(err);
      }

}


module.exports.viewpurchaseditems = async(req, res, next) => {
    console.log(req.body.email);
    const userpurchased = await Userpurchased.find({email:req.body.email});
    res.json(userpurchased); 
     
}