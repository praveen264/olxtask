const mongoose = require('mongoose');
const passport = require('passport');
const _ = require('lodash');

const User = mongoose.model('User');
const Userpurchased = mongoose.model('Userpurchased');
const Items = mongoose.model('Items');
const bcrypt = require('bcryptjs');
const nodemailer = require('nodemailer');
const v4 = require('uuid');
const uuidV4 = v4.v4()
require('dotenv').config();

module.exports.register = (req, res, next) => {
  var user = new User();
  user.fullName = req.body.fullName;
  user.email = req.body.email;
  user.username = req.body.username;
  user.password = req.body.password;
  user.verified = false;
  user.role = req.body.role;
  user.save((err, doc) => {
    if (!err) {
      res.send(doc);
      let transporter = nodemailer.createTransport({
        service: "gmail",
        auth: {
          user: process.env.AUTH_EMAIL,
          pass: process.env.AUTH_PASS
        }
      })

      transporter.verify((error, success) => {
        if (error) {
          console.log(error);
        }
        else {
          console.log("success");
          console.log(success);
        }
      })
      if (req.body.role != 'superadmin') {
        var mailOptions = {
          from: process.env.AUTH_EMAIL,
          to: req.body.email,
          subject: 'Sending Email using Node.js',
          text: 'That was easy! http://localhost:3000/api/verification/' + req.body.email + '/' + uuidV4
        };

        transporter.sendMail(mailOptions, function (error, info) {
          if (error) {
            console.log(error);
          } else {
            console.log('Email sent: ' + info.response);
          }
        });
      }
    }
    else {
      if (err.code == 11000)
        res.status(422).send(['You are registered with same username or password.']);
      else
        return next(err);
    }

  });
}

module.exports.authenticate = (req, res, next) => {
  // call for passport authentication
  passport.authenticate('local', (err, user, info) => {
    // error from passport middleware
    if (err) return res.status(400).json(err);
    // registered user
    else if (user) return res.status(200).json({ "token": user.generateJwt(), "user": user });
    // unknown user or wrong password
    else return res.status(404).json(info);
  })(req, res);
}

module.exports.userProfile = (req, res, next) => {
  User.findOne({ _id: req._id },
    (err, user) => {
      if (!user)
        return res.status(404).json({ status: false, message: 'User record not found.' });
      else
        return res.status(200).json({ status: true, user: _.pick(user, ['fullName', 'email', 'verified']) });
    }
  );
}







module.exports.forgotpassword = (req, res, next) => {
  let transporter = nodemailer.createTransport({
    host: "smtp.mailtrap.io",
    port: 2525,
    auth: {
      user: process.env.AUTH_EMAIL,
      pass: process.env.AUTH_PASS
    }
  })

  transporter.verify((error, success) => {
    if (error) {
      console.log(error);
    }
    else {
      console.log("success");
      console.log(success);
    }
  })

  bcrypt.genSalt(4, (err, salt) => {
    bcrypt.hash(req.body.email, salt, (err, hash) => {
      this.code = hash;
      // this.saltSecret = salt;
      // next();
      var mailOptions = {
        from: process.env.AUTH_EMA,
        to: req.body.email,
        subject: this.code,
        text: this.code
      };

      transporter.sendMail(mailOptions, function (error, info) {
        if (error) {
          console.log(error);
        } else {
          console.log('Email sent: ' + info.response);
        }
      });

    });
  });

}
module.exports.resetpassword = async (req, res, next) => {
  if (req.body.code == this.code) {
    console.log(req.body.email)
    var user = await User.findOne({ email: req.body.email });
    user.password = req.body.password;
    const a1 = await user.save();
    res.json(a1);
  }
  else {
    return false;
  }
}

// module.exports.changepassword = async (req, res, next) => {
//   var user = new User();
//   console.log
// }



module.exports.verification = async (req, res, next) => {
  if (req.params.id == uuidV4) {
    console.log('values are same');
    const items = await User.findOne({ email: req.params.email })
    //  items. name= 'req.body.name'
    //   items.email='req.body.email',
    //  items. username='ssdf',
    //  items. password= 'req.body.password'
    items.verified = true;
    const a1 = await items.save();
    res.json(a1)
  }
}


module.exports.items=async (req, res, next) =>{
  //res.json({'msg':"from items"});
  try {
          const items=await Items.find();
          res.json(items);
      } catch (error) {
          res.send('Error');
      }

}


module.exports.additems=async (req, res, next) =>{
  //res.json({'msg':"from items"});
  try {
    var items = new Items();
    items.itemname = req.body.itemname;
    items.category = req.body.category;
    items.price=req.body.price;
        //  const items=await Items.find();
        const a1 = await items.save();
          res.json(a1);
      } catch (error) {
          res.send('Error');
      }

}

module.exports.viewitem=async (req, res, next) =>{
  //res.json({'msg':"from items"});
  try {
    const items = await Items.find({ _id: req.params.id })
    // items.itemname = req.body.itemname;
    // items.category = req.body.category;
    // items.price=req.body.price;
    //     //  const items=await Items.find();
    //     const a1 = await items.save();
    //       res.json(a1);
    res.json(items);
    console.log(items);
      } catch (error) {
          res.send('Error');
      }

}