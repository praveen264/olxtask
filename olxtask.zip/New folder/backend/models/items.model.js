const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');

var userSchema = new mongoose.Schema({
    itemname: {
        type: String,
       
    },
    category: {
        type: String,
       
      
    },
    price: {
        type: String,
        
    }
});



mongoose.model('Items', userSchema);